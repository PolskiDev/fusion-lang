Cyanide Theme
===============

Thanks for downloading Cyanide Theme!
Feel free to open an issue on Github if you have any problem with the theme.

https://github.com/lefoy/cyanide-theme

** NEW: Cyanide Theme Builder **
More info: https://github.com/lefoy/cyanide-theme#cyanide-theme-builder
