
- `folder-open.png`, `folder-symlink.png` designed by [Dave Gandy](https://www.flaticon.com/authors/dave-gandy)
 from [www.flaticon.com](https://www.flaticon.com/) is licensed by [CC 3.0 BY](http://creativecommons.org/licenses/by/3.0/)
