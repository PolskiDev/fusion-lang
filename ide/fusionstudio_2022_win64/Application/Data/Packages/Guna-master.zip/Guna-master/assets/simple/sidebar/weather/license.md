
- `wX01.png`, `wX02.png`, `wX10.png`, designed by Linector
 from [www.flaticon.com](https://www.flaticon.com/) is licensed by [CC 3.0 BY](http://creativecommons.org/licenses/by/3.0/)

- `wX03.png`, `wX09.png`, `wX11.png`, `wX50.png`, `wX13.png` designed by [Freepik](http://www.freepik.com/)
 from [www.flaticon.com](https://www.flaticon.com/) is licensed by [CC 3.0 BY](http://creativecommons.org/licenses/by/3.0/)
