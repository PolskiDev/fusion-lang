
- `switch-panel.png` designed by [Freepik](http://www.freepik.com/)
 from [www.flaticon.com](https://www.flaticon.com/) is licensed by [CC 3.0 BY](http://creativecommons.org/licenses/by/3.0/)
